"""Jobs service domain."""
