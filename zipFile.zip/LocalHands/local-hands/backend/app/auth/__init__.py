"""Auth service domain."""
