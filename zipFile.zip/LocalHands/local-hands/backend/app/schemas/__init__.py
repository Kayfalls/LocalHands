"""Shared schema exports."""
